from django.contrib import admin
from django_otp.plugins.otp_totp.models import TOTPDevice
from unfold.admin import ModelAdmin


class CustomTOTPDeviceAdmin(ModelAdmin):
    """
    Custom admin for TOTPDevice with autocomplete user field
    """
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        """
        Use autocomplete widget for the user field
        """
        if db_field.name == "user":
            kwargs["widget"] = admin.widgets.AutocompleteSelect(
                db_field.remote_field, self.admin_site
            )
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
    
    # Improve the list view
    list_display = ('id', 'user', 'name', 'confirmed', 'created_at')
    list_filter = ('confirmed', 'created_at')
    
    # Add search functionality for the device list
    search_fields = ('user__username', 'user__email', 'user__name', 'name')
    
    # Organize fields in the form
    fieldsets = (
        ('Device Information', {
            'fields': ('user', 'name', 'confirmed')
        }),
        ('Configuration', {
            'fields': ('key', 'step', 'digits', 'tolerance', 'drift'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'last_used_at'),
            'classes': ('collapse',)
        }),
    )
    
    # Make some fields readonly
    readonly_fields = ('created_at', 'last_used_at')
    
    # Ordering
    ordering = ('-created_at',)
    
    # Items per page
    list_per_page = 25
    
    def get_queryset(self, request):
        """Optimize queryset with select_related for better performance"""
        return super().get_queryset(request).select_related('user')


# Export the admin class for use in urls.py
__all__ = ['CustomTOTPDeviceAdmin']
