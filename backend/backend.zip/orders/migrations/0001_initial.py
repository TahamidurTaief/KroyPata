# Generated manually to resolve circular dependency issue
# Orders tables already exist in database, this migration serves as a placeholder

from django.db import migrations


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        # Empty migration - tables already exist in database
        # This serves as a placeholder to establish migration history
    ]
