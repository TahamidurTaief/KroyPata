from django.core.management.base import BaseCommand
from products.models import Product
from products.serializers import ProductSerializer
from users.models import User
from django.test import RequestFactory

class Command(BaseCommand):
    help = 'Test minimum purchase API implementation'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('🚀 Testing Minimum Purchase API Implementation\n'))
        
        self.test_wholesaler_api()
        self.test_customer_api() 
        self.test_unauthenticated_api()
        
        self.stdout.write(self.style.SUCCESS('\n✅ API Tests completed!'))
        self.stdout.write('Next steps:')
        self.stdout.write('1. Start frontend server: npm run dev')
        self.stdout.write('2. Visit product pages and test the UI')
        self.stdout.write('3. Login as test_wholesaler@example.com')
        self.stdout.write('4. Test add to cart with minimum purchase validation')

    def test_wholesaler_api(self):
        """Test wholesaler API response"""
        self.stdout.write('🔍 Testing Wholesaler API Response')
        
        # Create a mock request with wholesaler user
        factory = RequestFactory()
        request = factory.get('/api/products/')
        
        try:
            # Get wholesaler user
            wholesaler = User.objects.filter(user_type='WHOLESALER').first()
            if not wholesaler:
                self.stdout.write(self.style.ERROR('❌ No wholesaler user found'))
                return
            
            request.user = wholesaler
            self.stdout.write(self.style.SUCCESS(f'✅ Using wholesaler: {wholesaler.email}'))
            
            # Get a product with wholesale price
            product = Product.objects.filter(wholesale_price__isnull=False).first()
            if not product:
                self.stdout.write(self.style.ERROR('❌ No product with wholesale price found'))
                return
            
            self.stdout.write(self.style.SUCCESS(f'✅ Testing product: {product.name}'))
            self.stdout.write(f'   - Regular price: {product.price}')
            self.stdout.write(f'   - Wholesale price: {product.wholesale_price}')
            self.stdout.write(f'   - Minimum purchase: {product.minimum_purchase}')
            
            # Serialize with wholesaler context
            serializer = ProductSerializer(product, context={'request': request})
            data = serializer.data
            
            self.stdout.write('\n📊 Wholesaler API Response:')
            self.stdout.write(f'   - Name: {data.get("name")}')
            self.stdout.write(f'   - Price: {data.get("price")}')
            self.stdout.write(f'   - Wholesale price: {data.get("wholesale_price")}')
            self.stdout.write(f'   - Minimum purchase: {data.get("minimum_purchase")}')
            
            if 'wholesale_price' in data and 'minimum_purchase' in data:
                self.stdout.write(self.style.SUCCESS('✅ Wholesaler can see wholesale_price and minimum_purchase'))
            else:
                self.stdout.write(self.style.ERROR('❌ Missing wholesale fields in API response'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'❌ Error testing wholesaler API: {e}'))

    def test_customer_api(self):
        """Test customer API response"""
        self.stdout.write('\n🔍 Testing Customer API Response')
        
        # Create a mock request with customer user
        factory = RequestFactory()
        request = factory.get('/api/products/')
        
        try:
            # Create or get a customer user
            customer, created = User.objects.get_or_create(
                email='test_customer@example.com',
                defaults={
                    'name': 'Test Customer',
                    'user_type': 'CUSTOMER',
                    'is_active': True
                }
            )
            
            request.user = customer
            self.stdout.write(self.style.SUCCESS(f'✅ Using customer: {customer.email}'))
            
            # Get the same product
            product = Product.objects.filter(wholesale_price__isnull=False).first()
            
            # Serialize with customer context
            serializer = ProductSerializer(product, context={'request': request})
            data = serializer.data
            
            self.stdout.write('\n📊 Customer API Response:')
            self.stdout.write(f'   - Name: {data.get("name")}')
            self.stdout.write(f'   - Price: {data.get("price")}')
            self.stdout.write(f'   - Wholesale price: {data.get("wholesale_price", "HIDDEN")}')
            self.stdout.write(f'   - Minimum purchase: {data.get("minimum_purchase", "HIDDEN")}')
            
            if 'wholesale_price' not in data and 'minimum_purchase' not in data:
                self.stdout.write(self.style.SUCCESS('✅ Customer cannot see wholesale_price and minimum_purchase'))
            else:
                self.stdout.write(self.style.ERROR('❌ Customer can see wholesale fields (security issue!)'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'❌ Error testing customer API: {e}'))

    def test_unauthenticated_api(self):
        """Test unauthenticated API response"""
        self.stdout.write('\n🔍 Testing Unauthenticated API Response')
        
        # Create a mock request without user
        factory = RequestFactory()
        request = factory.get('/api/products/')
        request.user = None
        
        try:
            # Get the same product
            product = Product.objects.filter(wholesale_price__isnull=False).first()
            
            # Serialize without authentication
            serializer = ProductSerializer(product, context={'request': request})
            data = serializer.data
            
            self.stdout.write('\n📊 Unauthenticated API Response:')
            self.stdout.write(f'   - Name: {data.get("name")}')
            self.stdout.write(f'   - Price: {data.get("price")}')
            self.stdout.write(f'   - Wholesale price: {data.get("wholesale_price", "HIDDEN")}')
            self.stdout.write(f'   - Minimum purchase: {data.get("minimum_purchase", "HIDDEN")}')
            
            if 'wholesale_price' not in data and 'minimum_purchase' not in data:
                self.stdout.write(self.style.SUCCESS('✅ Unauthenticated users cannot see wholesale fields'))
            else:
                self.stdout.write(self.style.ERROR('❌ Unauthenticated users can see wholesale fields (security issue!)'))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'❌ Error testing unauthenticated API: {e}'))